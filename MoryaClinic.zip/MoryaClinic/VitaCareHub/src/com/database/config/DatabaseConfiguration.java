package com.database.config;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages database connection settings.
 */
public class DatabaseConfiguration {
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/practo";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    /**
     * Provides a connection to the database.
     *
     * @return A Connection object to interact with the database.
     * @throws SQLException If the connection fails.
     */
    public static Connection getDatabaseConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
    }
}

