package com.morya.service;

import com.database.config.DatabaseConfiguration;
import com.morya.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles operations related to users.
 */
public class UserService {
    private Connection connection;

    /**
     * Initializes the UserService with a database connection.
     *
     * @throws SQLException If a database access error occurs.
     */
    public UserService() throws SQLException {
        this.connection = DatabaseConfiguration.getDatabaseConnection();
    }
    
    
    public User loginUser(String email, String password) throws SQLException {
        String query = "SELECT * FROM userdetails WHERE email = ? AND password = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("password"), rs.getLong("phone"));
        } else {
            return null; // Return null if login fails
        }
    }

    /**
     * Registers a new user in the database if the email does not already exist.
     *
     * @param user The user object containing user details.
     * @throws SQLException If a database access error occurs.
     */
    public void createUser(User user) throws SQLException {
        if (isUserExist(user.getEmail())) {
            throw new IllegalArgumentException("User with this email already exists.");
        }

        String query = "INSERT INTO userdetails (name, email, password, phone) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getPassword());
            statement.setLong(4, user.getPhone());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while inserting user: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Fetches all users from the database.
     *
     * @return A list of User objects.
     * @throws SQLException If a database access error occurs.
     */
    public List<User> getAllUsers() throws SQLException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM user_details";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                User user = new User(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("password"),
                        resultSet.getLong("phone")
                );
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Error while fetching users: " + e.getMessage());
            throw e;
        }
        return users;
    }

    /**
     * Updates the details of an existing user.
     *
     * @param user The user object containing updated details.
     * @throws SQLException If a database access error occurs.
     */
    public void updateUser(User user) throws SQLException {
        String query = "UPDATE userdetails SET name = ?, email = ?, password = ?, phone = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getPassword());
            statement.setLong(4, user.getPhone());
            statement.setInt(5, user.getId());
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated == 0) {
                throw new IllegalArgumentException("User not found with ID: " + user.getId());
            }
        } catch (SQLException e) {
            System.err.println("Error while updating user: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Deletes a user from the database.
     *
     * @param userId The ID of the user to be deleted.
     * @throws SQLException If a database access error occurs.
     */
    public void deleteUser(int userId) throws SQLException {
        String query = "DELETE FROM userdetails WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted == 0) {
                throw new IllegalArgumentException("User not found with ID: " + userId);
            }
        } catch (SQLException e) {
            System.err.println("Error while deleting user: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Searches for users by name.
     *
     * @param name The name to search for.
     * @return A list of User objects matching the search criteria.
     * @throws SQLException If a database access error occurs.
     */
    public List<User> searchUsersByName(String name) throws SQLException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM userdetails WHERE name LIKE ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, "%" + name + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    User user = new User(
                            resultSet.getInt("id"),
                            resultSet.getString("name"),
                            resultSet.getString("email"),
                            resultSet.getString("password"),
                            resultSet.getLong("phone")
                    );
                    users.add(user);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while searching users: " + e.getMessage());
            throw e;
        }
        return users;
    }

    /**
     * Checks if a user with the given email already exists.
     *
     * @param email The email to check.
     * @return True if the user exists, false otherwise.
     * @throws SQLException If a database access error occurs.
     */
    private boolean isUserExist(String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM userdetails WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error while checking user existence: " + e.getMessage());
            throw e;
        }
    }
}
