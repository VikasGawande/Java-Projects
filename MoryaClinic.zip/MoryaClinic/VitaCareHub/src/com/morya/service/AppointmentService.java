package com.morya.service;

import com.database.config.DatabaseConfiguration;
import com.morya.model.Appointment;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles operations related to appointments.
 */
public class AppointmentService {

    private Connection connection;

    /**
     * Initializes the AppointmentService with a database connection.
     *
     * @throws SQLException If a database access error occurs.
     */
    public AppointmentService() throws SQLException {
        this.connection = DatabaseConfiguration.getDatabaseConnection();
    }

    /**
     * Schedules a new appointment in the database.
     *
     * @param appointment The Appointment object containing appointment details.
     * @throws SQLException If a database access error occurs.
     */
    public void createAppointment(Appointment appointment) throws SQLException {
        String query = "INSERT INTO appointments (patientName, patientPhone, patientage, patientgender, " +
                "bloodgroup, appointmentdate, appointmenttime, addr, patientemail) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, appointment.getPatientName());
            statement.setLong(2, appointment.getPatientPhone());
            statement.setInt(3, appointment.getPatientAge());
            statement.setString(4, appointment.getPatientGender());
            statement.setString(5, appointment.getBloodGroup());
            statement.setDate(6, appointment.getAppointmentDate());
            statement.setTime(7, appointment.getAppointmentTime());
            statement.setString(8, appointment.getAddress());
            statement.setString(9, appointment.getPatientEmail());
            statement.setString(10, appointment.getDoctorName());
            statement.setLong(11, appointment.getDoctorPhone());
            statement.setString(12, appointment.getTestName());
            statement.setInt(13, appointment.getUserId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while scheduling appointment: " + e.getMessage());
            throw e; // Re-throwing exception for higher-level handling
        }
    }

    /**
     * Retrieves all appointments from the database.
     *
     * @return A list of Appointment objects.
     * @throws SQLException If a database access error occurs.
     */
    public List<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String query = "SELECT * FROM appointments";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                Appointment appointment = new Appointment(
                        resultSet.getInt("aid"),
                        resultSet.getString("patientname"),
                        resultSet.getLong("patientphone"),
                        resultSet.getInt("patientage"),
                        resultSet.getString("patientgender"),
                        resultSet.getString("bloodgroup"),
                        resultSet.getDate("appointmentdate"),
                        resultSet.getTime("appointmenttime"),
                        resultSet.getString("addr"),
                        resultSet.getString("patientemail"),
                        resultSet.getString("doctorname"),
                        resultSet.getLong("doctorphone"),
                        resultSet.getString("testname"),
                        resultSet.getInt("userid")
                );
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving appointments: " + e.getMessage());
            throw e; // Re-throwing exception for higher-level handling
        }
        return appointments;
    }

    /**
     * Retrieves the most recent appointment ID for a given user.
     *
     * @param userId The user ID to look for.
     * @return The most recent appointment ID or -1 if none found.
     * @throws SQLException If a database access error occurs.
     */
    public int getMostRecentAppointmentId(int userId) throws SQLException {
        int appointmentId = -1; // Default value if no appointment found
        String query = "SELECT appointment_id FROM appointments WHERE user_id = ? ORDER BY appointment_date DESC, appointment_time DESC LIMIT 1";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                appointmentId = resultSet.getInt("appointment_id");
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving the most recent appointment ID: " + e.getMessage());
            throw e; // Re-throwing exception for higher-level handling
        }
        return appointmentId;
    }
}
