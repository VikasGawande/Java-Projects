package com.morya.service;

import com.database.config.DatabaseConfiguration;
import com.morya.model.Test;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles operations related to test details.
 */
public class TestService {

    private Connection connection;

    /**
     * Initializes the TestService with a database connection.
     *
     * @throws SQLException If a database access error occurs.
     */
    public TestService() throws SQLException {
        this.connection = DatabaseConfiguration.getDatabaseConnection();
    }

    /**
     * Adds a new test detail to the database.
     *
     * @param testDetail The Test object containing test information.
     * @throws SQLException If a database access error occurs.
     */
    public void createTestDetail(Test test) throws SQLException {
        String query = "INSERT INTO TestDetails (test_name, price, test_date, appointment_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, test.getTestName());
            statement.setDouble(2, test.getPrice());
            statement.setDate(3, test.getTestDate());
            statement.setInt(4, test.getAppointmentId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error while adding test detail: " + e.getMessage());
            throw e; // Re-throwing exception for higher-level handling
        }
    }

    /**
     * Retrieves all test details from the database.
     *
     * @return A list of TestDetail objects.
     * @throws SQLException If a database access error occurs.
     */
    public List<Test> getAllTestDetails() throws SQLException {
        List<Test> testDetails = new ArrayList<>();
        String query = "SELECT * FROM TestDetails";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                Test testDetail = new Test(
                        resultSet.getInt("tid"),
                        resultSet.getString("test_name"),
                        resultSet.getDouble("price"),
                        resultSet.getDate("test_date"),
                        resultSet.getInt("appointment_id")
                );
                testDetails.add(testDetail);
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving test details: " + e.getMessage());
            throw e; // Re-throwing exception for higher-level handling
        }
        return testDetails;
    }
}
