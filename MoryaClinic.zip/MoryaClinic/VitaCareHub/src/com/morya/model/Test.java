package com.morya.model;

import java.sql.Date;

/**
 * Represents a test detail in the system.
 */
public class Test {
    private int tid;
    private String testName;
    private double price;
    private Date testDate;
    private int appointmentId;

    /**
     * Constructor for TestDetail.
     *
     * @param tid             Unique identifier for the test.
     * @param testName        Name of the test.
     * @param price           Price of the test.
     * @param testDate        Date of the test.
     * @param appointmentId   ID of the related appointment.
     */
    public Test(int tid, String testName, double price, Date testDate, int appointmentId) {
        this.tid = tid;
        this.testName = testName;
        this.price = price;
        this.testDate = testDate;
        this.appointmentId = appointmentId;
    }

    // Getters and Setters

    /**
     * Gets the ID of the test.
     *
     * @return ID of the test.
     */
    public int getTid() {
        return tid;
    }

    /**
     * Sets the ID of the test.
     *
     * @param tid Unique identifier for the test.
     */
    public void setTid(int tid) {
        this.tid = tid;
    }

    /**
     * Gets the name of the test.
     *
     * @return Name of the test.
     */
    public String getTestName() {
        return testName;
    }

    /**
     * Sets the name of the test.
     *
     * @param testName Name of the test.
     */
    public void setTestName(String testName) {
        this.testName = testName;
    }

    /**
     * Gets the price of the test.
     *
     * @return Price of the test.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price of the test.
     *
     * @param price Price of the test.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the date of the test.
     *
     * @return Date of the test.
     */
    public Date getTestDate() {
        return testDate;
    }

    /**
     * Sets the date of the test.
     *
     * @param testDate Date of the test.
     */
    public void setTestDate(Date testDate) {
        this.testDate = testDate;
    }

    /**
     * Gets the ID of the related appointment.
     *
     * @return ID of the related appointment.
     */
    public int getAppointmentId() {
        return appointmentId;
    }

    /**
     * Sets the ID of the related appointment.
     *
     * @param appointmentId ID of the related appointment.
     */
    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    /**
     * Returns a string representation of the TestDetail object.
     *
     * @return String representation of the TestDetail.
     */
    @Override
    public String toString() {
        return "TestDetail{" +
                "tid=" + tid +
                ", testName='" + testName + '\'' +
                ", price=" + price +
                ", testDate=" + testDate +
                ", appointmentId=" + appointmentId +
                '}';
    }
}
