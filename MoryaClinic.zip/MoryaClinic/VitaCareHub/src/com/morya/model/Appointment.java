package com.morya.model;

import java.sql.Date;
import java.sql.Time;

/**
 * Represents an appointment in the system.
 */
public class Appointment {
    private int appointmentId;
    private String patientName;
    private long patientPhone;
    private int patientAge;
    private String patientGender;
    private String bloodGroup;
    private Date appointmentDate;
    private Time appointmentTime;
    private String address;
    private String patientEmail;
    private String doctorName;
    private long doctorPhone;
    private String testName;
    private int userId;

    /**
     * Constructor for Appointment.
     *
     * @param appointmentId   Unique identifier for the appointment.
     * @param patientName     Name of the patient.
     * @param patientPhone    Phone number of the patient.
     * @param patientAge      Age of the patient.
     * @param patientGender   Gender of the patient.
     * @param bloodGroup      Blood group of the patient.
     * @param appointmentDate Date of the appointment.
     * @param appointmentTime Time of the appointment.
     * @param address         Address for the appointment.
     * @param patientEmail    Email address of the patient.
     * @param doctorName      Name of the doctor.
     * @param doctorPhone     Phone number of the doctor.
     * @param testName        Name of the test.
     * @param userId          ID of the user who created the appointment.
     */
    public Appointment(int appointmentId, String patientName, long patientPhone, int patientAge,
                       String patientGender, String bloodGroup, Date appointmentDate,
                       Time appointmentTime, String address, String patientEmail,
                       String doctorName, long doctorPhone, String testName, int userId) {
        this.appointmentId = appointmentId;
        this.patientName = patientName;
        this.patientPhone = patientPhone;
        this.patientAge = patientAge;
        this.patientGender = patientGender;
        this.bloodGroup = bloodGroup;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.address = address;
        this.patientEmail = patientEmail;
        this.doctorName = doctorName;
        this.doctorPhone = doctorPhone;
        this.testName = testName;
        this.userId = userId;
    }

    // Getters and Setters

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public long getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(long patientPhone) {
        this.patientPhone = patientPhone;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientGender() {
        return patientGender;
    }

    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public Time getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(Time appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public long getDoctorPhone() {
        return doctorPhone;
    }

    public void setDoctorPhone(long doctorPhone) {
        this.doctorPhone = doctorPhone;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Returns a string representation of the Appointment object.
     *
     * @return String representation of the Appointment.
     */
    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId=" + appointmentId +
                ", patientName='" + patientName + '\'' +
                ", patientPhone=" + patientPhone +
                ", patientAge=" + patientAge +
                ", patientGender='" + patientGender + '\'' +
                ", bloodGroup='" + bloodGroup + '\'' +
                ", appointmentDate=" + appointmentDate +
                ", appointmentTime=" + appointmentTime +
                ", address='" + address + '\'' +
                ", patientEmail='" + patientEmail + '\'' +
                ", doctorName='" + doctorName + '\'' +
                ", doctorPhone=" + doctorPhone +
                ", testName='" + testName + '\'' +
                ", userId=" + userId +
                '}';
    }
}
