package com.moryaclinic.cli;

import com.morya.model.Appointment;
import com.morya.model.Test;
import com.morya.model.User;
import com.morya.service.AppointmentService;
import com.morya.service.TestService;
import com.morya.service.UserService;

import java.util.Scanner;
import java.sql.Date;
import java.sql.Time;
import java.sql.SQLException;
import java.util.List;

public class MainApplication {
    private static User loggedInUser = null;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            UserService userService = new UserService();
            AppointmentService appointmentService = new AppointmentService();
            TestService testService = new TestService();

            while (true) {
                if (loggedInUser == null) {
                    System.out.println("1. Log In");
                    System.out.println("2. Create User");
                    System.out.println("3. Exit");
                    System.out.print("Choose an option: ");
                    int option = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    switch (option) {
                        case 1:
                            System.out.println("Enter your email:");
                            String email = scanner.nextLine();
                            System.out.println("Enter your password:");
                            String password = scanner.nextLine();

                            User user = userService.loginUser(email, password);
                            if (user != null) {
                                loggedInUser = user;
                                System.out.println("Login successful. Welcome, " + user.getName() + "!");
                            } else {
                                System.out.println("Invalid email or password. Please try again.");
                            }
                            break;

                        case 2:
                            System.out.println("Enter user details:");
                            System.out.print("Name: ");
                            String name = scanner.nextLine();
                            System.out.print("Email: ");
                            email = scanner.nextLine();
                            System.out.print("Password: ");
                            password = scanner.nextLine();
                            long phone = readPhoneNumber(scanner);
                            User newUser = new User(0, name, email, password, phone);
                            userService.createUser(newUser);
                            System.out.println("User created successfully.");
                            break;

                        case 3:
                            System.out.println("Exiting...");
                            return;

                        default:
                            System.out.println("Invalid option. Please try again.");
                            break;
                    }
                } else {
                    System.out.println("1. Schedule Appointment");
                    System.out.println("2. Add Test Detail");
                    System.out.println("3. List Users");
                    System.out.println("4. List Appointments");
                    System.out.println("5. List Test Details");
                    System.out.println("6. Log Out");
                    System.out.println("7. Exit");
                    System.out.print("Choose an option: ");
                    int option = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    switch (option) {
                        case 1:
                            scheduleAppointment(scanner, userService, appointmentService);
                            break;

                        case 2:
                            addTestDetail(scanner, testService, appointmentService);
                            break;

                        case 3:
                            listUsers(userService);
                            break;

                        case 4:
                            listAppointments(appointmentService);
                            break;

                        case 5:
                            listTestDetails(testService);
                            break;

                        case 6:
                            System.out.println("Logging out...");
                            loggedInUser = null;
                            break;

                        case 7:
                            System.out.println("Exiting...");
                            return;

                        default:
                            System.out.println("Invalid option. Please try again.");
                            break;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            scanner.close(); // Ensure scanner is closed
        }
    }

    private static void scheduleAppointment(Scanner scanner, UserService userService, AppointmentService appointmentService) throws SQLException {
        System.out.println("Enter appointment details:");
        System.out.print("Patient Name: ");
        String patientName = scanner.nextLine();
        System.out.print("Patient Phone: ");
        long patientPhone = readPhoneNumber(scanner);
        System.out.print("Patient Age: ");
        int patientAge = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Patient Gender: ");
        String patientGender = scanner.nextLine();
        System.out.print("Blood Group: ");
        String bloodGroup = scanner.nextLine();
        System.out.print("Appointment Date (YYYY-MM-DD): ");
        String dateStr = scanner.nextLine();
        Date appointmentDate = Date.valueOf(dateStr);
        System.out.print("Appointment Time (HH:MM:SS): ");
        String timeStr = scanner.nextLine();
        Time appointmentTime = Time.valueOf(timeStr);
        System.out.print("Address: ");
        String address = scanner.nextLine();
        System.out.print("Patient Email: ");
        String patientEmail = scanner.nextLine();
        System.out.print("Doctor Name: ");
        String doctorName = scanner.nextLine();
        System.out.print("Doctor Phone: ");
        long doctorPhone = readPhoneNumber(scanner);
        System.out.print("Test Name: ");
        String testName = scanner.nextLine();

        // Use the logged-in user's ID
        int userId = loggedInUser.getId();

        Appointment appointment = new Appointment(0, patientName, patientPhone, patientAge, patientGender,
                bloodGroup, appointmentDate, appointmentTime, address, patientEmail, doctorName, doctorPhone, testName, userId);
        appointmentService.createAppointment(appointment);
        System.out.println("Appointment scheduled successfully.");
    }

    private static void addTestDetail(Scanner scanner, TestService testService, AppointmentService appointmentService) throws SQLException {
        System.out.println("Enter test details:");
        System.out.print("Test Name: ");
        String testNameDetail = scanner.nextLine();
        System.out.print("Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        System.out.print("Test Date (YYYY-MM-DD): ");
        String testDateStr = scanner.nextLine();
        Date testDate = Date.valueOf(testDateStr);
        int appointmentId = appointmentService.getMostRecentAppointmentId(loggedInUser.getId());

        Test testDetail = new Test(0, testNameDetail, price, testDate, appointmentId);
        testService.createTestDetail(testDetail);
        System.out.println("Test detail added successfully.");
    }

    private static long readPhoneNumber(Scanner scanner) {
        while (true) {
            System.out.print("Phone: ");
            String input = scanner.nextLine();
            if (input.matches("\\d{10}")) { // Validate for 10-digit numbers
                return Long.parseLong(input);
            } else {
                System.out.println("Invalid phone number. Please enter a 10-digit number.");
            }
        }
    }

    private static void listUsers(UserService userService) throws SQLException {
    	System.out.println(" ");
        System.out.println("List of users:");
        List<User> users = userService.getAllUsers();

        System.out.printf("%-10s %-20s %-30s %-15s%n", "ID", "Name", "Email", "Phone");
        System.out.println("---------------------------------------------------------------");

        for (User user : users) {
            System.out.printf("%-10d %-20s %-30s %-15d%n",
                    user.getId(), user.getName(), user.getEmail(), user.getPhone());
        }
    }

    private static void listAppointments(AppointmentService appointmentService) throws SQLException {
    	System.out.println(" ");
        System.out.println("List of appointments:");
        List<Appointment> appointments = appointmentService.getAllAppointments();

        System.out.printf("%-10s %-20s %-15s %-5s %-10s %-12s %-12s %-25s %-30s %-20s %-15s %-15s%n",
                "ID", "Patient Name", "Phone", "Age", "Gender", "Blood Group", "Date", "Time", "Address",
                "Patient Email", "Doctor Name", "Doctor Phone");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------");

        for (Appointment a : appointments) {
            System.out.printf("%-10d %-20s %-15d %-5d %-10s %-12s %-12s %-25s %-30s %-20s %-15s %-15d%n",
                    a.getAppointmentId(), a.getPatientName(), a.getPatientPhone(), a.getPatientAge(), a.getPatientGender(),
                    a.getBloodGroup(), a.getAppointmentDate(), a.getAppointmentTime(), a.getAddress(),
                    a.getPatientEmail(), a.getDoctorName(), a.getDoctorPhone());
        }
    }

    private static void listTestDetails(TestService testService) throws SQLException {
    	System.out.println(" ");
        System.out.println("List of test details:");
        List<Test> testDetails = testService.getAllTestDetails();

        System.out.printf("%-10s %-20s %-10s %-12s%n", "Test ID", "Test Name", "Price", "Date");
        System.out.println("-------------------------------------------------------------");

        for (Test t : testDetails) {
            System.out.printf("%-10d %-20s %-10.2f %-12s%n", t.getTid(), t.getTestName(), t.getPrice(), t.getTestDate());
        }
    }
}
