package com.detaconfig;

public class DataConfig {
	public static final String URL = "jdbc:mysql://localhost:3306/practo";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "root";

}
