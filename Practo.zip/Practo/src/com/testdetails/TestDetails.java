package com.testdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.detaconfig.DataConfig;

public class TestDetails {
	
	static Scanner scn=new Scanner(System.in);
	public static int addTestDetails() {
        int k = 0;
        try {
            Connection con = DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME, DataConfig.PASSWORD);
            PreparedStatement pstmt = con.prepareStatement(
                    "INSERT INTO testDetails (test_name, test_date, price, appointmentId) VALUES (?, ?, ?, ?)");
            
            System.out.println("Enter test name:");
            String testName = scn.nextLine();
            pstmt.setString(1, testName);
            
            System.out.println("Enter test date (YYYY-MM-DD):");
            String testDate = scn.nextLine();
            pstmt.setDate(2, java.sql.Date.valueOf(testDate));
            
            System.out.println("Enter test price:");
            double price = scn.nextDouble();
            pstmt.setDouble(3, price);
            
            System.out.println("Enter appointment ID:");
            int appointmentId = scn.nextInt();
            pstmt.setInt(4, appointmentId);
            
            // Log values
            System.out.println("Inserting Test Details: " + testName + ", " + testDate + ", " + price + ", " + appointmentId);
            
            // Execute update and check result
            k = pstmt.executeUpdate();
            if (k > 0) {
                System.out.println("Test details added successfully.");
            } else {
                System.out.println("Failed to add test details.");
            }

        } catch (SQLException e) {
            System.out.println("SQL Error Code: " + e.getErrorCode());
            System.out.println("SQL State: " + e.getSQLState());
            System.out.println("Error Message: " + e.getMessage());
            e.printStackTrace();
        }
        return k;
    }
	
	public static void viewTestDetails(int appointmentId) {
        try {
            Connection con = DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME, DataConfig.PASSWORD);
            PreparedStatement pstmt = con.prepareStatement("SELECT * FROM testDetails WHERE appointmentId = ?");
            pstmt.setInt(1, appointmentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (!rs.isBeforeFirst()) {
                System.out.println("No Tests found for this patient.");
                return;
            }
            
            while (rs.next()) {
                System.out.println("Test ID: " + rs.getInt("test_id"));
                System.out.println("Test Name: " + rs.getString("test_name"));
                System.out.println("Test Date: " + rs.getDate("test_date"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("----------------------------");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
