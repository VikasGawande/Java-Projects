package com.appoiment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.detaconfig.DataConfig;

public class Appoiment {
	static Scanner scn=new Scanner(System.in);
	public static int bookAppoitment() {
		int k=0;
		try {
			Connection con = DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME, DataConfig.PASSWORD);
            PreparedStatement pstmt = con.prepareStatement("INSERT INTO appointments (patient_name, patient_phone, patient_age, patient_gender, blood_grp, appointment_date, appointment_time, address, patient_email, doctor_name,doctor_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
            
            System.out.println("Enter patient name:");
            String name = scn.nextLine();
            pstmt.setString(1, name);
            
            System.out.println("Enter patient phone:");
            Long phone = scn.nextLong();
            pstmt.setLong(2, phone);
            
            System.out.println("Enter patient age:");
            int age = scn.nextInt();
            pstmt.setInt(3, age);
            
            scn.nextLine(); // Consume newline
            System.out.println("Enter patient gender:");
            String gender = scn.nextLine();
            pstmt.setString(4, gender);
            
            System.out.println("Enter blood group:");
            String bloodGrp = scn.nextLine();
            pstmt.setString(5, bloodGrp);
            
            System.out.println("Enter appointment date (YYYY-MM-DD):");
            String appointmentDate = scn.nextLine();
            pstmt.setDate(6, java.sql.Date.valueOf(appointmentDate));
            
            System.out.println("Enter appointment time (HH:MM:SS):");
            String appointmentTime = scn.nextLine();
            pstmt.setTime(7, java.sql.Time.valueOf(appointmentTime));
            
            System.out.println("Enter patient address:");
            String address = scn.nextLine();
            pstmt.setString(8, address);
            
            System.out.println("Enter patient email:");
            String email = scn.nextLine();
            pstmt.setString(9, email);
            
            System.out.println("Enter doctor name:");
            String doctorName = scn.nextLine();
            pstmt.setString(10, doctorName);
            
            System.out.println("Enter doctor contact:");
            Long mo=scn.nextLong();
            pstmt.setLong(11, mo);
            
            k = pstmt.executeUpdate();
            
            return k;
		}catch(Exception e) {
			System.out.println();
		}
		return k;
				
	}
	
	public static void viewAppointmentForPatient() {
        try {
            Connection con = DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME, DataConfig.PASSWORD);
            
            System.out.println("Enter patient email to view appointments:");
            String email = scn.nextLine();
            
            PreparedStatement pstmt = con.prepareStatement("SELECT * FROM appointments WHERE patient_email = ?");
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (!rs.isBeforeFirst()) {
                System.out.println("No appointments found for this patient.");
                return;
            }
            
            while (rs.next()) {
                System.out.println("Appointment ID: " + rs.getInt("appointment_id"));
                System.out.println("Patient Name: " + rs.getString("patient_name"));
                System.out.println("Doctor Name: " + rs.getString("doctor_name"));
                System.out.println("Appointment Date: " + rs.getDate("appointment_date"));
                System.out.println("Appointment Time: " + rs.getTime("appointment_time"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("----------------------------");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static int delete() {
		int k=0;
		try {
			Connection con = DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME, DataConfig.PASSWORD);
            PreparedStatement pstmt =con.prepareStatement("DELETE FROM appointments WHERE appointment_id = ?");
            System.out.println("Showing appointment details");
    		Appoiment.viewAppointmentForPatient();
    		System.out.println();
    		System.out.println("To Delete Appointment enter appoinment id: ");
    		int id=scn.nextInt();
    		pstmt.setInt(1, id);
    		k=pstmt.executeUpdate();
    		return k;
    		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return k;
		
	}
}
