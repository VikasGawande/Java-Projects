package com.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.detaconfig.DataConfig;

public class User {
	public static int register() {
		int k=0;
		Scanner scn=new Scanner(System.in);
		try {
			Connection con=DriverManager.getConnection(DataConfig.URL,DataConfig.USERNAME,DataConfig.PASSWORD);
			PreparedStatement pstmt = con.prepareStatement("insert into user values (?,?,?,?,?)");
			System.out.println("Enter the user name:");
			String name=scn.nextLine();
			pstmt.setString(1, name);
			
			System.out.println("Enter the user email:");
			String email=scn.nextLine();
			pstmt.setString(2, email);
			
			System.out.println("Enter the user pass:");
			String pass=scn.nextLine();
			pstmt.setString(3, pass);
			
			System.out.println("Enter the user age:");
			int age=scn.nextInt();
			pstmt.setInt(4, age);
			
			System.out.println("Enter the user mobile no:");
			Long mo=scn.nextLong();
			pstmt.setLong(5, mo);
			k=pstmt.executeUpdate();
			return k;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return k;
	}
	
	public static int update() {
		int k=0;
		boolean b=true;
		Scanner scn=new Scanner(System.in);
		try {
			Connection con=DriverManager.getConnection(DataConfig.URL,DataConfig.USERNAME,DataConfig.PASSWORD);
			PreparedStatement up_name = con.prepareStatement("update user set name=? where email=?");
			PreparedStatement up_pass = con.prepareStatement("update user set pass=? where email=?");
			PreparedStatement up_age = con.prepareStatement("update user set age=? where email=?");
			PreparedStatement up_phone = con.prepareStatement("update user set phone=? where email=?");
			PreparedStatement up_all = con.prepareStatement("update user set name=?,phone=? where email=?");
			while(b) {
				System.out.println("Welcome to Update Section");
				System.out.println("1. Update Name");
				System.out.println("2. Update Pass");
				System.out.println("3. Update age");
				System.out.println("4. Update Mobile no");
				System.out.println("5. Update All");
				System.out.println("6. exit");
				System.out.println("Enter your choice");
				int choice=scn.nextInt();
				switch(choice) {
				 case 1:
					 System.out.println("Enter new name: ");
					 scn.nextLine();
					 String name=scn.nextLine();
					 up_name.setString(1, name);
					 
					 System.out.println("Enter the user email:");
					 String email=scn.nextLine();
					 up_name.setString(2, email);
					 k=up_name.executeUpdate();
					 if(k>0) {
						 System.out.println("Name Updated Successfully");
					 }else {
						 System.out.println("Something went wrong name not update");
					 }
					 return k;
				 case 2:
					 System.out.println("Enter new pass: ");
					 scn.nextLine();
					 String pass=scn.nextLine();
					 up_pass.setString(1, pass);
					 
					 System.out.println("Enter the user email:");
					 email=scn.nextLine();
					 up_pass.setString(2, email);
					 k=up_pass.executeUpdate();
					 if(k>0) {
						 System.out.println("Passwprd Updated Successfully");
					 }else {
						 System.out.println("Something went wrong Password not update");
					 }
					 return k;
				 case 3:
					 System.out.println("Enter new age: ");
					 scn.nextLine();
					 int age=scn.nextInt();
					 up_age.setInt(1, age);
					 scn.nextLine();
					 
					 System.out.println("Enter the user email:");
					 email=scn.nextLine();
					 up_age.setString(2, email);
					 k=up_age.executeUpdate();
					 if(k>0) {
						 System.out.println("Age Updated Successfully");
					 }else {
						 System.out.println("Something went wrong Age not update");
					 }
					 return k;
				 case 4:
					 System.out.println("Enter new Phone number: ");
					 scn.nextLine();
					 long mo=scn.nextInt();
					 up_phone.setLong(1, mo);
					 scn.nextLine();
					 
					 System.out.println("Enter the user email:");
					 email=scn.nextLine();
					 up_phone.setString(2, email);
					 k=up_phone.executeUpdate();
					 if(k>0) {
						 System.out.println("Phone Updated Successfully");
					 }else {
						 System.out.println("Something went wrong Phone not update");
					 }
					 return k;
				 case 5:
					 System.out.println("Enter new name: ");
					 scn.nextLine();
					 name=scn.nextLine();
					 up_all.setString(1, name);
											
					System.out.println("Enter the user pass:");
					pass=scn.nextLine();
					up_all.setString(2, pass);
						
					System.out.println("Enter the user age:");
					age=scn.nextInt();
					up_all.setInt(3, age);
						
					System.out.println("Enter the user mobile no:");
					mo=scn.nextLong();
					up_all.setLong(4, mo);
					
					k=up_all.executeUpdate();
					if(k>0) {
						 System.out.println(" Updated Successfully");
					 }else {
						 System.out.println("Something went wrong Phone  update");
					 }
					 return k;
				 case 6:
					 b=false;
					 break;
				}
			}
			return k;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return k;
	}
}
