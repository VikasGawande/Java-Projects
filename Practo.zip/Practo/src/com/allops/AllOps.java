package com.allops;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.appoiment.Appoiment;
import com.detaconfig.DataConfig;
import com.testdetails.TestDetails;
import com.user.User;


public class AllOps {
	
	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		boolean b=true;
		int k=0;
		try {
			Connection con= DriverManager.getConnection(DataConfig.URL, DataConfig.USERNAME,DataConfig.PASSWORD);
			PreparedStatement user_log=con.prepareStatement("select * from user where email=? and pass=?");
			while(b) {
				System.out.println("Welcome to Practo Appp");
				System.out.println("1.Register");
				System.out.println("2.Login");
				System.out.println("3.exit");
				System.out.print("Enter your choice: ");
				int choice=scn.nextInt();
				switch(choice) {
					case 1:
						System.out.println("Welcome to user register");
						k= User.register();
						if(k>0) {
							System.out.println("User registered!!!");
						}else {
							System.out.println("Something went wrong");
						}
						break;
					case 2:
						boolean flag=true;
						while(true) {
							System.out.println("Welcome to Login Section");
							System.out.println("1.UserLogin");
							System.out.println("2.AdminLogin");
							System.out.println("3.exit");
							System.out.print("Enter your choice: ");
							int c=scn.nextInt();
							switch(c) {
								case 1:
									System.out.println("Welcome to User Login:");
								    scn.nextLine();  // Consume the leftover newline
								    System.out.println("Enter the user email:");
								    String email = scn.nextLine();

								    System.out.println("Enter the user pass:");
								    String pass = scn.nextLine();  
								    user_log.setString(1, email);
								    user_log.setString(2, pass);

								    ResultSet rs = user_log.executeQuery();
								    if (rs.next()) { 
								        System.out.println("Welcome " + rs.getString(1)); 
								        System.out.println();
								        boolean f=true;
								        while(f) {
								        	System.out.println("1.Update");
								        	System.out.println("2.Book Appoiment");
								        	System.out.println("3.View Appoiment");
								        	System.out.println("4.Update Appoiment");
								        	System.out.println("5.Book Test");
								        	System.out.println("6.View Test Details");
								        	System.out.println("7.Cancel Appoiment");
								        	System.out.println("8.Exit");
								       
								        	System.out.println("Enter your choice:");
								        	int y=scn.nextInt();
								        	switch(y) {
								        		case 1:
								        			k=User.update();
								        			break;
								        		case 2:
								        			k=Appoiment.bookAppoitment();
								        			if (k > 0) {
								                        System.out.println("Appointment booked successfully!");
								                    } else {
								                        System.out.println("Something went wrong, appointment not booked.");
								                    }
//								        			System.out.println();
//								        			
								        			break;
								        		case 3:
								        			Appoiment.viewAppointmentForPatient();
								        			break;
								        		case 4:
								        			//update Appoiment
								        			break;
								        		case 5:
								        			System.out.println("Going for Diagnosis Lab for Test precscribe by Doctor:");
								        			TestDetails.addTestDetails();
								        			if (k > 0) {
								                        System.out.println("Test details added successfully.");
								                    } else {
								                        System.out.println("Failed to add test details.");
								                    }
								        			break;
								        		case 6:
								        			System.out.println("View Test Details: ");
								        			System.out.println("Enter appointment id: ");
								        			int id=scn.nextInt();
								        			TestDetails.viewTestDetails(id);
								        			break;
								        	    case 7:
								        		    k=Appoiment.delete();
								        		    if (k > 0) {
								                        System.out.println("Appointment cancelled successfully.");
								                    } else {
								                       System.out.println("Appointment not found.");
								                    }
								        		    break;
								        	   case 8:
								        		   flag=false;
								        		   break;
								        	}
								        }
								        
								        
								    } else {
								        System.out.println("Invalid email or password.");
								    }
								    break;
									
							}
						}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
