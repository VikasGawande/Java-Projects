package db_config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Databaseconfig {
    public static final String URL = "jdbc:mysql://localhost:3307/airways";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "root"; 
}
